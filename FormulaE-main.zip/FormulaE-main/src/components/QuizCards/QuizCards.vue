<script setup>
	import DifficultyCard from './DifficultyCard.vue';
  import WelcomeCard from './WelcomeCard.vue';
  import QuestionCard from './QuestionCard.vue';
  import CongratsCard from './CongratsCard.vue';
import LeaderboardCard from './LeaderboardCard.vue';  
</script>

<template>
  <WelcomeCard />
  <DifficultyCard />
  <QuestionCard />
  <CongratsCard />
  <LeaderboardCard />
</template>

<style scoped>

</style>